export default function Inbox() {
  return (
    <div>
      <h2>Inbox</h2>
    </div>
);}