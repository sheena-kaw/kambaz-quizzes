export default function Grades() {
    return(
        <h2> Grades</h2>
    );
}