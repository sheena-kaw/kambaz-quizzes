export default function Zoom() {
    return(
        <h2> Zoomies </h2>
    );
}