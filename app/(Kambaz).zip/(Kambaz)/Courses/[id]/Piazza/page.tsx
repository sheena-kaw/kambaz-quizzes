export default function Piazza() {
    return(
        <h2> Piazza </h2>
    );
}